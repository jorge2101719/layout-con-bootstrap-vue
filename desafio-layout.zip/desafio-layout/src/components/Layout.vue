<template>
    <div>
        <h1> Personajes </h1>
        <div>
            <b-card-group columns class="mt-3">
                <b-card v-for="(personaje, index) in personajes" :key="index" img-alt='personaje.nombre'>
                    <b-img :src='personaje.imagen'></b-img>
                    <hr>
                    <b-card-text> <h4> {{personaje.id}}. {{personaje.nombre}} </h4></b-card-text>
                </b-card>
            </b-card-group>
        </div>
    </div>
</template>

<script>
export default {
    name: 'Layout',
    data() {
        return {
            personajes: [{
                id: 1,
                nombre: "Rick",
                imagen: "https://rickandmortyapi.com/api/character/avatar/1.jpeg"
            },
            {
                id: 2,
                nombre: "Morty",
                imagen: "https://rickandmortyapi.com/api/character/avatar/2.jpeg"
            },
            {
                id: 3,
                nombre: "Summer",
                imagen: "https://rickandmortyapi.com/api/character/avatar/3.jpeg"
            },
            {
                id: 4,
                nombre: "Beth",
                imagen: "https://rickandmortyapi.com/api/character/avatar/4.jpeg"
            },
            {
                id: 5,
                nombre: "Jerry",
                imagen: "https://rickandmortyapi.com/api/character/avatar/5.jpeg"
            }
            ]
        }
    },
}
</script>


<style>
    body {
        font-size: 30pt;
        font-weight: 900;
        font-family: 'Times New Roman', Times, serif;
        color: green;
        //background-image: url('https://rickandmortypod.com/wp-content/uploads/2018/11/cropped-RM_page-header_background1-3.png');
    }
    .imagenes {
        display: inline;
    }
</style>
